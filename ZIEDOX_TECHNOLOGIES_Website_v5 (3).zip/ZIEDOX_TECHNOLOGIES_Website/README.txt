ZIEDOX TECHNOLOGIES WEBSITE — VERSION 4

PACKAGE CONTENTS
- Responsive company homepage
- Product pages: CTA School Management Suite, MARYAD Business Manager, Custom Software Solutions
- Portfolio, Careers, Privacy Policy and Terms pages
- SEO/social metadata, Organization structured data, sitemap.xml and robots.txt
- Improved mobile navigation and keyboard accessibility
- Email and WhatsApp contact options

IMPORTANT BEFORE PUBLICATION
1. The intended domain ziedoxtechnologies.com and email info@ziedoxtechnologies.com have not been verified as registered/active. Confirm ownership, DNS and mailbox delivery before publishing or relying on them.
2. The public-facing brand is ZIEDOX TECHNOLOGIES. Do not represent a legal name change or CAC registration as complete unless confirmed independently.
3. The enquiry form is static: it opens the visitor's email application. It does not save submissions to a database or send them to a server. WhatsApp opens a chat link. A hosted form/backend must be configured for online lead storage.
4. Privacy Policy and Terms are starter drafts and should be reviewed for the actual hosting, analytics, cookies, data handling and legal requirements before launch.
5. Sitemap URLs use the intended domain. Update them if a different final domain is used.
6. CTA School Management Suite supports offline/manual file exchange as described on its product page. Do not promise automatic remote synchronisation.
7. MARYAD Business Manager is browser-local/offline and single-device; it does not provide central cloud sync or a complete audited double-entry accounting service.
8. No fabricated client testimonials, customer logos or performance claims are included. Portfolio items describe products/capabilities only.
9. CTA Finance Manager is intentionally excluded from this website.

ANDROID PREVIEW
1. Download the ZIP.
2. Open Files / My Files > Downloads.
3. Tap the ZIP and choose Extract.
4. Open the extracted ZIEDOX_TECHNOLOGIES_Website folder.
5. Tap index.html and open it with Chrome.

For public access, upload the complete folder contents to a web host with HTTPS enabled. Keep the products folder and all root pages in their current locations.


Version 5 product showcase update:
- Added AUDI CARTOONZ PRINT as a product card on the homepage.
- Added products/audi-cartoonz-print.html with a feature overview and deployment prerequisites based on the supplied v20.5.1 package documentation.
- The product page clearly states that database configuration, incomplete modules and production security testing remain outstanding.
